from qgis.core import (
    QgsVectorLayer, QgsGeometry, QgsPoint, QgsPointXY, QgsFeature, QgsWkbTypes, QgsField
)
from qgis.PyQt.QtCore import QVariant

def reordenar_vertices_polilinha(input_layer, output_path=None):
    """
    Reordena os vértices de uma camada de polilinha.
    
    :param input_layer: Camada de entrada (QgsVectorLayer).
    :param output_path: Caminho para salvar a camada de saída (opcional).
                       Se None, a camada será criada em memória.
    :return: Camada de saída (QgsVectorLayer).
    """
    # Determina o tipo de geometria da camada de entrada
    if input_layer.wkbType() == QgsWkbTypes.MultiLineString:
        geometry_type = "MultiLineString"
    else:
        geometry_type = "LineString"

    # Cria a camada de saída com o mesmo tipo de geometria
    if output_path:
        output_layer = QgsVectorLayer(output_path, "PLUGIN_Passo_11", "ogr")
    else:
        output_layer = QgsVectorLayer(
            f"{geometry_type}?crs={input_layer.crs().authid()}", 
            "PLUGIN_Passo_11", 
            "memory"
        )

    # Copia os campos da camada de entrada para a camada de saída
    fields = input_layer.fields()
    
    # Adiciona um campo 'fid' se ele não existir
    if fields.indexOf('fid') == -1:
        fields.append(QgsField('fid', QVariant.Int))
    
    output_layer.dataProvider().addAttributes(fields)
    output_layer.updateFields()

    # Itera sobre as features da camada de entrada
    fid_counter = 1  # Contador para gerar valores sequenciais para o campo 'fid'
    for feature in input_layer.getFeatures():
        geom = feature.geometry()
        if geom.isEmpty():
            continue

        if geom.isMultipart():
            # Processa geometrias multipartes
            multi_linhas = []
            for parte in geom.asMultiPolyline():
                vertices = [QgsPoint(pt) for pt in parte]
                # Reordena os vértices
                processado = process_vertices(vertices)
                multi_linhas.append([QgsPointXY(pt) for pt in processado])
            new_geom = QgsGeometry.fromMultiPolylineXY(multi_linhas)
        else:
            # Processa geometrias simples
            vertices = [QgsPoint(pt) for pt in geom.asPolyline()]
            # Reordena os vértices
            processado = process_vertices(vertices)
            new_geom = QgsGeometry.fromPolylineXY([QgsPointXY(pt) for pt in processado])

        # Cria uma nova feature com a geometria reordenada
        new_feature = QgsFeature(fields)
        new_feature.setGeometry(new_geom)
        
        # Copia todos os atributos da feature original
        attributes = feature.attributes()
        
        # Se o campo 'fid' existir, define o valor sequencial
        if fields.indexOf('fid') != -1:
            attributes[fields.indexOf('fid')] = fid_counter
            fid_counter += 1
        
        new_feature.setAttributes(attributes)

        # Adiciona a feature à camada de saída
        output_layer.dataProvider().addFeature(new_feature)

    return output_layer

def process_vertices(vertices):
    """
    Reordena os vértices de uma lista de pontos.
    
    :param vertices: Lista de QgsPoint.
    :return: Lista de QgsPoint reordenada.
    """
    if not vertices:
        return []

    # Verificar se é fechado (opcional, dependendo dos seus dados)
    is_closed = vertices[0] == vertices[-1]

    # Remover último vértice se for fechado (para evitar duplicata)
    if is_closed:
        vertices = vertices[:-1]

    # Encontrar vértice mais a sudeste
    vertice_sudeste = max(vertices, key=lambda p: p.x() - p.y())
    idx = vertices.index(vertice_sudeste)

    # Reordenar vértices
    novos_vertices = vertices[idx:] + vertices[:idx]

    # Se necessário, adicionar vértice de fechamento novamente
    if is_closed:
        novos_vertices.append(novos_vertices[0])

    return novos_vertices